-- query72
-- source: queries/optimized/q72/query72_BEST.sql
-- split materialisation at default: -1.6s is inside this host's noise

SET SESSION sql_mode = CONCAT(@@sql_mode, ',IGNORE_SPACE,PIPES_AS_CONCAT');

select /*+ JOIN_PREFIX(d1, catalog_sales, household_demographics, customer_demographics) */
    i_item_desc
     , w_warehouse_name
     , d1.d_week_seq
     , sum(IF(p_promo_sk is null, 1, 0))     no_promo
     , sum(IF(p_promo_sk is not null, 1, 0)) promo
     , count(*)                              total_cnt
from catalog_sales
         join date_dim d1 on (cs_sold_date_sk = d1.d_date_sk)
         join inventory on (cs_item_sk = inv_item_sk)
         join warehouse on (w_warehouse_sk = inv_warehouse_sk)
         join item on (i_item_sk = cs_item_sk)
         join customer_demographics on (cs_bill_cdemo_sk = cd_demo_sk)
         join household_demographics on (cs_bill_hdemo_sk = hd_demo_sk)
         join date_dim d2 on (inv_date_sk = d2.d_date_sk)
         join date_dim d3 on (cs_ship_date_sk = d3.d_date_sk)
         left outer join promotion on (cs_promo_sk = p_promo_sk)
         left outer join catalog_returns on (cr_item_sk = cs_item_sk and cr_order_number = cs_order_number)
where d1.d_week_seq = d2.d_week_seq
  and inv_quantity_on_hand < cs_quantity
  and d3.d_date > d1.d_date + 5
  and hd_buy_potential = '1001-5000'
  and d1.d_year = 1999
  and cd_marital_status = 'M'
group by i_item_desc, w_warehouse_name, d1.d_week_seq
order by total_cnt desc, i_item_desc, w_warehouse_name, d_week_seq
limit 100;
