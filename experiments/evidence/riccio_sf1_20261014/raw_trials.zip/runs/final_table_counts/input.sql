SELECT 'call_center' AS table_name, COUNT(*) AS row_count FROM call_center
UNION ALL
SELECT 'catalog_page' AS table_name, COUNT(*) AS row_count FROM catalog_page
UNION ALL
SELECT 'catalog_returns' AS table_name, COUNT(*) AS row_count FROM catalog_returns
UNION ALL
SELECT 'catalog_sales' AS table_name, COUNT(*) AS row_count FROM catalog_sales
UNION ALL
SELECT 'customer' AS table_name, COUNT(*) AS row_count FROM customer
UNION ALL
SELECT 'customer_address' AS table_name, COUNT(*) AS row_count FROM customer_address
UNION ALL
SELECT 'customer_demographics' AS table_name, COUNT(*) AS row_count FROM customer_demographics
UNION ALL
SELECT 'date_dim' AS table_name, COUNT(*) AS row_count FROM date_dim
UNION ALL
SELECT 'dbgen_version' AS table_name, COUNT(*) AS row_count FROM dbgen_version
UNION ALL
SELECT 'household_demographics' AS table_name, COUNT(*) AS row_count FROM household_demographics
UNION ALL
SELECT 'income_band' AS table_name, COUNT(*) AS row_count FROM income_band
UNION ALL
SELECT 'inventory' AS table_name, COUNT(*) AS row_count FROM inventory
UNION ALL
SELECT 'item' AS table_name, COUNT(*) AS row_count FROM item
UNION ALL
SELECT 'promotion' AS table_name, COUNT(*) AS row_count FROM promotion
UNION ALL
SELECT 'reason' AS table_name, COUNT(*) AS row_count FROM reason
UNION ALL
SELECT 'ship_mode' AS table_name, COUNT(*) AS row_count FROM ship_mode
UNION ALL
SELECT 'store' AS table_name, COUNT(*) AS row_count FROM store
UNION ALL
SELECT 'store_returns' AS table_name, COUNT(*) AS row_count FROM store_returns
UNION ALL
SELECT 'store_sales' AS table_name, COUNT(*) AS row_count FROM store_sales
UNION ALL
SELECT 'time_dim' AS table_name, COUNT(*) AS row_count FROM time_dim
UNION ALL
SELECT 'warehouse' AS table_name, COUNT(*) AS row_count FROM warehouse
UNION ALL
SELECT 'web_page' AS table_name, COUNT(*) AS row_count FROM web_page
UNION ALL
SELECT 'web_returns' AS table_name, COUNT(*) AS row_count FROM web_returns
UNION ALL
SELECT 'web_sales' AS table_name, COUNT(*) AS row_count FROM web_sales
UNION ALL
SELECT 'web_site' AS table_name, COUNT(*) AS row_count FROM web_site
ORDER BY table_name;
