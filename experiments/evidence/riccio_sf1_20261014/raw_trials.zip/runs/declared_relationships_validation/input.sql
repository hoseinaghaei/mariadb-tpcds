-- Read-only checks; NULL foreign keys are not orphans.
SELECT 'call_center.cc_d1' AS relationship, COUNT(*) AS orphan_count
FROM `call_center` c LEFT JOIN `date_dim` p ON c.`cc_closed_date_sk`=p.`d_date_sk`
WHERE c.`cc_closed_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'call_center.cc_d2' AS relationship, COUNT(*) AS orphan_count
FROM `call_center` c LEFT JOIN `date_dim` p ON c.`cc_open_date_sk`=p.`d_date_sk`
WHERE c.`cc_open_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'catalog_page.cp_d1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_page` c LEFT JOIN `date_dim` p ON c.`cp_end_date_sk`=p.`d_date_sk`
WHERE c.`cp_end_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'catalog_page.cp_d2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_page` c LEFT JOIN `date_dim` p ON c.`cp_start_date_sk`=p.`d_date_sk`
WHERE c.`cp_start_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_cc' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `call_center` p ON c.`cr_call_center_sk`=p.`cc_call_center_sk`
WHERE c.`cr_call_center_sk` IS NOT NULL AND p.`cc_call_center_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_cp' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `catalog_page` p ON c.`cr_catalog_page_sk`=p.`cp_catalog_page_sk`
WHERE c.`cr_catalog_page_sk` IS NOT NULL AND p.`cp_catalog_page_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_i' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `item` p ON c.`cr_item_sk`=p.`i_item_sk`
WHERE c.`cr_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_r' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `reason` p ON c.`cr_reason_sk`=p.`r_reason_sk`
WHERE c.`cr_reason_sk` IS NOT NULL AND p.`r_reason_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_a1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `customer_address` p ON c.`cr_refunded_addr_sk`=p.`ca_address_sk`
WHERE c.`cr_refunded_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_cd1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `customer_demographics` p ON c.`cr_refunded_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`cr_refunded_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_c1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `customer` p ON c.`cr_refunded_customer_sk`=p.`c_customer_sk`
WHERE c.`cr_refunded_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_hd1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `household_demographics` p ON c.`cr_refunded_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`cr_refunded_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_d1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `date_dim` p ON c.`cr_returned_date_sk`=p.`d_date_sk`
WHERE c.`cr_returned_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_i_2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `time_dim` p ON c.`cr_returned_time_sk`=p.`t_time_sk`
WHERE c.`cr_returned_time_sk` IS NOT NULL AND p.`t_time_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_a2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `customer_address` p ON c.`cr_returning_addr_sk`=p.`ca_address_sk`
WHERE c.`cr_returning_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_cd2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `customer_demographics` p ON c.`cr_returning_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`cr_returning_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_c2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `customer` p ON c.`cr_returning_customer_sk`=p.`c_customer_sk`
WHERE c.`cr_returning_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_hd2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `household_demographics` p ON c.`cr_returning_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`cr_returning_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_sm' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `ship_mode` p ON c.`cr_ship_mode_sk`=p.`sm_ship_mode_sk`
WHERE c.`cr_ship_mode_sk` IS NOT NULL AND p.`sm_ship_mode_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_w2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `warehouse` p ON c.`cr_warehouse_sk`=p.`w_warehouse_sk`
WHERE c.`cr_warehouse_sk` IS NOT NULL AND p.`w_warehouse_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_b_a' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `customer_address` p ON c.`cs_bill_addr_sk`=p.`ca_address_sk`
WHERE c.`cs_bill_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_b_cd' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `customer_demographics` p ON c.`cs_bill_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`cs_bill_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_b_c' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `customer` p ON c.`cs_bill_customer_sk`=p.`c_customer_sk`
WHERE c.`cs_bill_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_b_hd' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `household_demographics` p ON c.`cs_bill_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`cs_bill_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_cc' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `call_center` p ON c.`cs_call_center_sk`=p.`cc_call_center_sk`
WHERE c.`cs_call_center_sk` IS NOT NULL AND p.`cc_call_center_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_cp' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `catalog_page` p ON c.`cs_catalog_page_sk`=p.`cp_catalog_page_sk`
WHERE c.`cs_catalog_page_sk` IS NOT NULL AND p.`cp_catalog_page_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_i' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `item` p ON c.`cs_item_sk`=p.`i_item_sk`
WHERE c.`cs_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_p' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `promotion` p ON c.`cs_promo_sk`=p.`p_promo_sk`
WHERE c.`cs_promo_sk` IS NOT NULL AND p.`p_promo_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_s_a' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `customer_address` p ON c.`cs_ship_addr_sk`=p.`ca_address_sk`
WHERE c.`cs_ship_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_s_cd' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `customer_demographics` p ON c.`cs_ship_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`cs_ship_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_s_c' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `customer` p ON c.`cs_ship_customer_sk`=p.`c_customer_sk`
WHERE c.`cs_ship_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_d1' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `date_dim` p ON c.`cs_ship_date_sk`=p.`d_date_sk`
WHERE c.`cs_ship_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_s_hd' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `household_demographics` p ON c.`cs_ship_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`cs_ship_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_sm' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `ship_mode` p ON c.`cs_ship_mode_sk`=p.`sm_ship_mode_sk`
WHERE c.`cs_ship_mode_sk` IS NOT NULL AND p.`sm_ship_mode_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_d2' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `date_dim` p ON c.`cs_sold_date_sk`=p.`d_date_sk`
WHERE c.`cs_sold_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_t' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `time_dim` p ON c.`cs_sold_time_sk`=p.`t_time_sk`
WHERE c.`cs_sold_time_sk` IS NOT NULL AND p.`t_time_sk` IS NULL
UNION ALL
SELECT 'catalog_sales.cs_w' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_sales` c LEFT JOIN `warehouse` p ON c.`cs_warehouse_sk`=p.`w_warehouse_sk`
WHERE c.`cs_warehouse_sk` IS NOT NULL AND p.`w_warehouse_sk` IS NULL
UNION ALL
SELECT 'customer.c_a' AS relationship, COUNT(*) AS orphan_count
FROM `customer` c LEFT JOIN `customer_address` p ON c.`c_current_addr_sk`=p.`ca_address_sk`
WHERE c.`c_current_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'customer.c_cd' AS relationship, COUNT(*) AS orphan_count
FROM `customer` c LEFT JOIN `customer_demographics` p ON c.`c_current_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`c_current_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'customer.c_hd' AS relationship, COUNT(*) AS orphan_count
FROM `customer` c LEFT JOIN `household_demographics` p ON c.`c_current_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`c_current_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'customer.c_fsd' AS relationship, COUNT(*) AS orphan_count
FROM `customer` c LEFT JOIN `date_dim` p ON c.`c_first_sales_date_sk`=p.`d_date_sk`
WHERE c.`c_first_sales_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'customer.c_fsd2' AS relationship, COUNT(*) AS orphan_count
FROM `customer` c LEFT JOIN `date_dim` p ON c.`c_first_shipto_date_sk`=p.`d_date_sk`
WHERE c.`c_first_shipto_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'household_demographics.hd_ib' AS relationship, COUNT(*) AS orphan_count
FROM `household_demographics` c LEFT JOIN `income_band` p ON c.`hd_income_band_sk`=p.`ib_income_band_sk`
WHERE c.`hd_income_band_sk` IS NOT NULL AND p.`ib_income_band_sk` IS NULL
UNION ALL
SELECT 'inventory.inv_d' AS relationship, COUNT(*) AS orphan_count
FROM `inventory` c LEFT JOIN `date_dim` p ON c.`inv_date_sk`=p.`d_date_sk`
WHERE c.`inv_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'inventory.inv_i' AS relationship, COUNT(*) AS orphan_count
FROM `inventory` c LEFT JOIN `item` p ON c.`inv_item_sk`=p.`i_item_sk`
WHERE c.`inv_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'inventory.inv_w' AS relationship, COUNT(*) AS orphan_count
FROM `inventory` c LEFT JOIN `warehouse` p ON c.`inv_warehouse_sk`=p.`w_warehouse_sk`
WHERE c.`inv_warehouse_sk` IS NOT NULL AND p.`w_warehouse_sk` IS NULL
UNION ALL
SELECT 'promotion.p_end_date' AS relationship, COUNT(*) AS orphan_count
FROM `promotion` c LEFT JOIN `date_dim` p ON c.`p_end_date_sk`=p.`d_date_sk`
WHERE c.`p_end_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'promotion.p_i' AS relationship, COUNT(*) AS orphan_count
FROM `promotion` c LEFT JOIN `item` p ON c.`p_item_sk`=p.`i_item_sk`
WHERE c.`p_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'promotion.p_start_date' AS relationship, COUNT(*) AS orphan_count
FROM `promotion` c LEFT JOIN `date_dim` p ON c.`p_start_date_sk`=p.`d_date_sk`
WHERE c.`p_start_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'store.s_close_date' AS relationship, COUNT(*) AS orphan_count
FROM `store` c LEFT JOIN `date_dim` p ON c.`s_closed_date_sk`=p.`d_date_sk`
WHERE c.`s_closed_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_a' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `customer_address` p ON c.`sr_addr_sk`=p.`ca_address_sk`
WHERE c.`sr_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_cd' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `customer_demographics` p ON c.`sr_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`sr_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_c' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `customer` p ON c.`sr_customer_sk`=p.`c_customer_sk`
WHERE c.`sr_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_hd' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `household_demographics` p ON c.`sr_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`sr_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_i' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `item` p ON c.`sr_item_sk`=p.`i_item_sk`
WHERE c.`sr_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_r' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `reason` p ON c.`sr_reason_sk`=p.`r_reason_sk`
WHERE c.`sr_reason_sk` IS NOT NULL AND p.`r_reason_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_ret_d' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `date_dim` p ON c.`sr_returned_date_sk`=p.`d_date_sk`
WHERE c.`sr_returned_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_t' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `time_dim` p ON c.`sr_return_time_sk`=p.`t_time_sk`
WHERE c.`sr_return_time_sk` IS NOT NULL AND p.`t_time_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_s' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `store` p ON c.`sr_store_sk`=p.`s_store_sk`
WHERE c.`sr_store_sk` IS NOT NULL AND p.`s_store_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_a' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `customer_address` p ON c.`ss_addr_sk`=p.`ca_address_sk`
WHERE c.`ss_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_cd' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `customer_demographics` p ON c.`ss_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`ss_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_c' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `customer` p ON c.`ss_customer_sk`=p.`c_customer_sk`
WHERE c.`ss_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_hd' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `household_demographics` p ON c.`ss_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`ss_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_i' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `item` p ON c.`ss_item_sk`=p.`i_item_sk`
WHERE c.`ss_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_p' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `promotion` p ON c.`ss_promo_sk`=p.`p_promo_sk`
WHERE c.`ss_promo_sk` IS NOT NULL AND p.`p_promo_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_d' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `date_dim` p ON c.`ss_sold_date_sk`=p.`d_date_sk`
WHERE c.`ss_sold_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_t' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `time_dim` p ON c.`ss_sold_time_sk`=p.`t_time_sk`
WHERE c.`ss_sold_time_sk` IS NOT NULL AND p.`t_time_sk` IS NULL
UNION ALL
SELECT 'store_sales.ss_s' AS relationship, COUNT(*) AS orphan_count
FROM `store_sales` c LEFT JOIN `store` p ON c.`ss_store_sk`=p.`s_store_sk`
WHERE c.`ss_store_sk` IS NOT NULL AND p.`s_store_sk` IS NULL
UNION ALL
SELECT 'web_page.wp_ad' AS relationship, COUNT(*) AS orphan_count
FROM `web_page` c LEFT JOIN `date_dim` p ON c.`wp_access_date_sk`=p.`d_date_sk`
WHERE c.`wp_access_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'web_page.wp_cd' AS relationship, COUNT(*) AS orphan_count
FROM `web_page` c LEFT JOIN `date_dim` p ON c.`wp_creation_date_sk`=p.`d_date_sk`
WHERE c.`wp_creation_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_i' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `item` p ON c.`wr_item_sk`=p.`i_item_sk`
WHERE c.`wr_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_r' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `reason` p ON c.`wr_reason_sk`=p.`r_reason_sk`
WHERE c.`wr_reason_sk` IS NOT NULL AND p.`r_reason_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ref_a' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `customer_address` p ON c.`wr_refunded_addr_sk`=p.`ca_address_sk`
WHERE c.`wr_refunded_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ref_cd' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `customer_demographics` p ON c.`wr_refunded_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`wr_refunded_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ref_c' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `customer` p ON c.`wr_refunded_customer_sk`=p.`c_customer_sk`
WHERE c.`wr_refunded_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ref_hd' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `household_demographics` p ON c.`wr_refunded_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`wr_refunded_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ret_d' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `date_dim` p ON c.`wr_returned_date_sk`=p.`d_date_sk`
WHERE c.`wr_returned_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ret_t' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `time_dim` p ON c.`wr_returned_time_sk`=p.`t_time_sk`
WHERE c.`wr_returned_time_sk` IS NOT NULL AND p.`t_time_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ret_a' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `customer_address` p ON c.`wr_returning_addr_sk`=p.`ca_address_sk`
WHERE c.`wr_returning_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ret_cd' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `customer_demographics` p ON c.`wr_returning_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`wr_returning_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ret_c' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `customer` p ON c.`wr_returning_customer_sk`=p.`c_customer_sk`
WHERE c.`wr_returning_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_ret_cd_2' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `household_demographics` p ON c.`wr_returning_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`wr_returning_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_wp' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `web_page` p ON c.`wr_web_page_sk`=p.`wp_web_page_sk`
WHERE c.`wr_web_page_sk` IS NOT NULL AND p.`wp_web_page_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_b_a' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `customer_address` p ON c.`ws_bill_addr_sk`=p.`ca_address_sk`
WHERE c.`ws_bill_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_b_cd' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `customer_demographics` p ON c.`ws_bill_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`ws_bill_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_b_c' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `customer` p ON c.`ws_bill_customer_sk`=p.`c_customer_sk`
WHERE c.`ws_bill_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_b_cd_2' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `household_demographics` p ON c.`ws_bill_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`ws_bill_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_i' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `item` p ON c.`ws_item_sk`=p.`i_item_sk`
WHERE c.`ws_item_sk` IS NOT NULL AND p.`i_item_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_p' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `promotion` p ON c.`ws_promo_sk`=p.`p_promo_sk`
WHERE c.`ws_promo_sk` IS NOT NULL AND p.`p_promo_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_s_a' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `customer_address` p ON c.`ws_ship_addr_sk`=p.`ca_address_sk`
WHERE c.`ws_ship_addr_sk` IS NOT NULL AND p.`ca_address_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_s_cd' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `customer_demographics` p ON c.`ws_ship_cdemo_sk`=p.`cd_demo_sk`
WHERE c.`ws_ship_cdemo_sk` IS NOT NULL AND p.`cd_demo_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_s_c' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `customer` p ON c.`ws_ship_customer_sk`=p.`c_customer_sk`
WHERE c.`ws_ship_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_s_d' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `date_dim` p ON c.`ws_ship_date_sk`=p.`d_date_sk`
WHERE c.`ws_ship_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_s_hd' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `household_demographics` p ON c.`ws_ship_hdemo_sk`=p.`hd_demo_sk`
WHERE c.`ws_ship_hdemo_sk` IS NOT NULL AND p.`hd_demo_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_sm' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `ship_mode` p ON c.`ws_ship_mode_sk`=p.`sm_ship_mode_sk`
WHERE c.`ws_ship_mode_sk` IS NOT NULL AND p.`sm_ship_mode_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_d2' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `date_dim` p ON c.`ws_sold_date_sk`=p.`d_date_sk`
WHERE c.`ws_sold_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_t' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `time_dim` p ON c.`ws_sold_time_sk`=p.`t_time_sk`
WHERE c.`ws_sold_time_sk` IS NOT NULL AND p.`t_time_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_w2' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `warehouse` p ON c.`ws_warehouse_sk`=p.`w_warehouse_sk`
WHERE c.`ws_warehouse_sk` IS NOT NULL AND p.`w_warehouse_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_wp' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `web_page` p ON c.`ws_web_page_sk`=p.`wp_web_page_sk`
WHERE c.`ws_web_page_sk` IS NOT NULL AND p.`wp_web_page_sk` IS NULL
UNION ALL
SELECT 'web_sales.ws_ws' AS relationship, COUNT(*) AS orphan_count
FROM `web_sales` c LEFT JOIN `web_site` p ON c.`ws_web_site_sk`=p.`web_site_sk`
WHERE c.`ws_web_site_sk` IS NOT NULL AND p.`web_site_sk` IS NULL
UNION ALL
SELECT 'web_site.web_d1' AS relationship, COUNT(*) AS orphan_count
FROM `web_site` c LEFT JOIN `date_dim` p ON c.`web_close_date_sk`=p.`d_date_sk`
WHERE c.`web_close_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'web_site.web_d2' AS relationship, COUNT(*) AS orphan_count
FROM `web_site` c LEFT JOIN `date_dim` p ON c.`web_open_date_sk`=p.`d_date_sk`
WHERE c.`web_open_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'customer.c_d' AS relationship, COUNT(*) AS orphan_count
FROM `customer` c LEFT JOIN `date_dim` p ON c.`c_last_review_date_sk`=p.`d_date_sk`
WHERE c.`c_last_review_date_sk` IS NOT NULL AND p.`d_date_sk` IS NULL
UNION ALL
SELECT 'store_returns.sr_i_tn' AS relationship, COUNT(*) AS orphan_count
FROM `store_returns` c LEFT JOIN `store_sales` p ON c.`sr_item_sk`=p.`ss_item_sk` AND c.`sr_ticket_number`=p.`ss_ticket_number`
WHERE c.`sr_item_sk` IS NOT NULL AND c.`sr_ticket_number` IS NOT NULL AND p.`ss_item_sk` IS NULL
UNION ALL
SELECT 'catalog_returns.cr_i_on' AS relationship, COUNT(*) AS orphan_count
FROM `catalog_returns` c LEFT JOIN `catalog_sales` p ON c.`cr_item_sk`=p.`cs_item_sk` AND c.`cr_order_number`=p.`cs_order_number`
WHERE c.`cr_item_sk` IS NOT NULL AND c.`cr_order_number` IS NOT NULL AND p.`cs_item_sk` IS NULL
UNION ALL
SELECT 'web_returns.wr_i_on' AS relationship, COUNT(*) AS orphan_count
FROM `web_returns` c LEFT JOIN `web_sales` p ON c.`wr_item_sk`=p.`ws_item_sk` AND c.`wr_order_number`=p.`ws_order_number`
WHERE c.`wr_item_sk` IS NOT NULL AND c.`wr_order_number` IS NOT NULL AND p.`ws_item_sk` IS NULL
UNION ALL
SELECT 'web_page.wp_c' AS relationship, COUNT(*) AS orphan_count
FROM `web_page` c LEFT JOIN `customer` p ON c.`wp_customer_sk`=p.`c_customer_sk`
WHERE c.`wp_customer_sk` IS NOT NULL AND p.`c_customer_sk` IS NULL
ORDER BY relationship;
