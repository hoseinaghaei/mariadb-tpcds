USE tpcds_riccio_sf1;
SELECT VERSION() AS server_version,DATABASE() AS database_name,
 @@global.innodb_buffer_pool_size AS buffer_pool_bytes,
 @@session.tmp_table_size AS tmp_table_size,@@session.max_heap_table_size AS max_heap_table_size;
SELECT COUNT(*) AS secondary_indexes FROM
 (SELECT DISTINCT TABLE_NAME,INDEX_NAME FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA=DATABASE() AND INDEX_NAME <> 'PRIMARY') AS ix;
SELECT TABLE_NAME,INDEX_NAME,SEQ_IN_INDEX,COLUMN_NAME,IGNORED
 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE()
 ORDER BY TABLE_NAME,INDEX_NAME,SEQ_IN_INDEX;
SELECT SUM(DATA_LENGTH) AS table_data_bytes,SUM(INDEX_LENGTH) AS secondary_index_bytes
 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE();
SELECT * FROM dbgen_version;
