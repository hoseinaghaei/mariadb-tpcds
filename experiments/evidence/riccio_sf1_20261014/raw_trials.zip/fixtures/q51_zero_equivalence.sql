-- Synthetic equivalence fixture; temporary tables shadow the source tables for this session only.
CREATE TEMPORARY TABLE date_dim (d_date_sk BIGINT PRIMARY KEY,d_date DATE,d_month_seq BIGINT);
INSERT INTO date_dim VALUES
(1,'1998-01-01',1176),
(2,'1998-01-02',1176),
(3,'1998-01-03',1176),
(4,'1997-12-31',1175);
CREATE TEMPORARY TABLE web_sales (ws_item_sk BIGINT,ws_sold_date_sk BIGINT,ws_sales_price DECIMAL(7,2));
INSERT INTO web_sales VALUES
(1,1,4),
(1,1,1),
(1,3,1),
(2,1,10),
(2,2,-8),
(3,1,NULL),
(4,2,9),
(5,1,10),
(1,4,999),
(NULL,1,100);
CREATE TEMPORARY TABLE store_sales (ss_item_sk BIGINT,ss_sold_date_sk BIGINT,ss_sales_price DECIMAL(7,2));
INSERT INTO store_sales VALUES
(1,2,4),
(1,3,6),
(2,1,5),
(2,3,5),
(3,2,2),
(4,1,NULL),
(4,3,0),
(6,1,10),
(1,4,1),
(NULL,1,0);

-- Baseline result set(s)
WITH web_v1 as (
select
  ws_item_sk item_sk, d_date,
  sum(sum(ws_sales_price))
      over (partition by ws_item_sk order by d_date rows between unbounded preceding and current row) cume_sales
from web_sales
    ,date_dim
where ws_sold_date_sk=d_date_sk
  and d_month_seq between 1176 and 1176+11
  and ws_item_sk is not NULL
group by ws_item_sk, d_date),
store_v1 as (
select
  ss_item_sk item_sk, d_date,
  sum(sum(ss_sales_price))
      over (partition by ss_item_sk order by d_date rows between unbounded preceding and current row) cume_sales
from store_sales
    ,date_dim
where ss_sold_date_sk=d_date_sk
  and d_month_seq between 1176 and 1176+11
  and ss_item_sk is not NULL
group by ss_item_sk, d_date)
 select  *
from (select item_sk
     ,d_date
     ,web_sales
     ,store_sales
     ,max(web_sales)
         over (partition by item_sk order by d_date rows between unbounded preceding and current row) web_cumulative
     ,max(store_sales)
         over (partition by item_sk order by d_date rows between unbounded preceding and current row) store_cumulative
     from (
           -- MariaDB has no FULL OUTER JOIN: emulated as
           -- (A LEFT JOIN B) UNION ALL (A RIGHT JOIN B WHERE A keys IS NULL).
           -- The anti-join filter on the second branch keeps only the B rows
           -- that found no A match, so UNION ALL adds no duplicates and
           -- legitimate duplicate rows are preserved.
           (select case when web.item_sk is not null then web.item_sk else store.item_sk end item_sk
                  ,case when web.d_date is not null then web.d_date else store.d_date end d_date
                  ,web.cume_sales web_sales
                  ,store.cume_sales store_sales
            from web_v1 web left outer join store_v1 store on (web.item_sk = store.item_sk
                                                           and web.d_date = store.d_date))
           union all
           (select case when web.item_sk is not null then web.item_sk else store.item_sk end item_sk
                  ,case when web.d_date is not null then web.d_date else store.d_date end d_date
                  ,web.cume_sales web_sales
                  ,store.cume_sales store_sales
            from web_v1 web right outer join store_v1 store on (web.item_sk = store.item_sk
                                                            and web.d_date = store.d_date)
            where web.item_sk is null
              and web.d_date is null)
          )x )y
where web_cumulative > store_cumulative
order by item_sk
        ,d_date
limit 100;

-- Candidate result set(s)
-- Daily channel groups are unique on (item_sk,d_date).
-- Combine those keys once, preserve channel presence, and retain both
-- the original running SUM and subsequent running MAX operations.
WITH channel_daily AS (
    SELECT ws_item_sk AS item_sk, d_date, 'w' AS channel,
           SUM(ws_sales_price) AS daily_sales
    FROM web_sales
    JOIN date_dim ON ws_sold_date_sk = d_date_sk
    WHERE d_month_seq BETWEEN 1176 AND 1176+11
      AND ws_item_sk IS NOT NULL
    GROUP BY ws_item_sk, d_date
    UNION ALL
    SELECT ss_item_sk AS item_sk, d_date, 's' AS channel,
           SUM(ss_sales_price) AS daily_sales
    FROM store_sales
    JOIN date_dim ON ss_sold_date_sk = d_date_sk
    WHERE d_month_seq BETWEEN 1176 AND 1176+11
      AND ss_item_sk IS NOT NULL
    GROUP BY ss_item_sk, d_date
),
daily AS (
    SELECT item_sk, d_date,
           MAX(CASE WHEN channel = 'w' THEN daily_sales END) AS web_daily,
           MAX(CASE WHEN channel = 's' THEN daily_sales END) AS store_daily,
           MAX(CASE WHEN channel = 'w' THEN 1 ELSE 0 END) AS has_web,
           MAX(CASE WHEN channel = 's' THEN 1 ELSE 0 END) AS has_store
    FROM channel_daily
    GROUP BY item_sk, d_date
),
running AS (
    SELECT item_sk, d_date, has_web, has_store,
           SUM(web_daily) OVER (
               PARTITION BY item_sk ORDER BY d_date
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
           ) AS web_running,
           SUM(store_daily) OVER (
               PARTITION BY item_sk ORDER BY d_date
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
           ) AS store_running
    FROM daily
),
masked AS (
    SELECT item_sk, d_date,
           CASE WHEN has_web = 1 THEN web_running END AS web_sales,
           CASE WHEN has_store = 1 THEN store_running END AS store_sales
    FROM running
),
y AS (
    SELECT item_sk, d_date, web_sales, store_sales,
           MAX(web_sales) OVER (
               PARTITION BY item_sk ORDER BY d_date
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
           ) AS web_cumulative,
           MAX(store_sales) OVER (
               PARTITION BY item_sk ORDER BY d_date
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
           ) AS store_cumulative
    FROM masked
)
SELECT item_sk, d_date, web_sales, store_sales, web_cumulative, store_cumulative
FROM y
WHERE web_cumulative > store_cumulative
ORDER BY item_sk, d_date
LIMIT 100;

