-- Synthetic equivalence fixture; temporary tables shadow the source tables for this session only.
CREATE TEMPORARY TABLE date_dim (d_date_sk BIGINT PRIMARY KEY,d_date DATE);
INSERT INTO date_dim VALUES
(1,'1998-08-28'),
(2,'1998-09-11'),
(3,'1998-09-12'),
(4,'1998-07-01'),
(5,'1998-08-27');
CREATE TEMPORARY TABLE store (s_store_sk BIGINT PRIMARY KEY,s_store_id CHAR(16));
INSERT INTO store VALUES
(1,'SAME'),
(2,'SAME'),
(3,'OTHER');
CREATE TEMPORARY TABLE catalog_page (cp_catalog_page_sk BIGINT PRIMARY KEY,cp_catalog_page_id CHAR(16));
INSERT INTO catalog_page VALUES
(1,'P1'),
(2,'P2');
CREATE TEMPORARY TABLE web_site (web_site_sk BIGINT PRIMARY KEY,web_site_id CHAR(16));
INSERT INTO web_site VALUES
(1,'W1'),
(2,'W2');
CREATE TEMPORARY TABLE store_sales (ss_store_sk BIGINT,ss_sold_date_sk BIGINT,ss_ext_sales_price DECIMAL(7,2),ss_net_profit DECIMAL(7,2));
INSERT INTO store_sales VALUES
(1,1,50,10),
(2,2,25,5),
(1,3,999,999),
(1,NULL,999,999),
(99,1,300,20),
(3,1,NULL,NULL);
CREATE TEMPORARY TABLE store_returns (sr_store_sk BIGINT,sr_returned_date_sk BIGINT,sr_return_amt DECIMAL(7,2),sr_net_loss DECIMAL(7,2));
INSERT INTO store_returns VALUES
(1,1,5,1),
(3,2,NULL,NULL);
CREATE TEMPORARY TABLE catalog_sales (cs_catalog_page_sk BIGINT,cs_sold_date_sk BIGINT,cs_ext_sales_price DECIMAL(7,2),cs_net_profit DECIMAL(7,2));
INSERT INTO catalog_sales VALUES
(1,1,100,20),
(2,2,NULL,7),
(1,3,500,50);
CREATE TEMPORARY TABLE catalog_returns (cr_catalog_page_sk BIGINT,cr_returned_date_sk BIGINT,cr_return_amount DECIMAL(7,2),cr_net_loss DECIMAL(7,2));
INSERT INTO catalog_returns VALUES
(1,1,10,3),
(2,2,NULL,NULL);
CREATE TEMPORARY TABLE web_sales (ws_item_sk BIGINT,ws_order_number BIGINT,ws_web_site_sk BIGINT,ws_sold_date_sk BIGINT,ws_ext_sales_price DECIMAL(7,2),ws_net_profit DECIMAL(7,2),PRIMARY KEY(ws_item_sk,ws_order_number));
INSERT INTO web_sales VALUES
(1,100,1,4,500,60),
(2,200,2,1,40,8),
(3,300,2,2,NULL,NULL),
(4,400,1,5,99,9);
CREATE TEMPORARY TABLE web_returns (wr_item_sk BIGINT,wr_order_number BIGINT,wr_returned_date_sk BIGINT,wr_return_amt DECIMAL(7,2),wr_net_loss DECIMAL(7,2));
INSERT INTO web_returns VALUES
(1,100,2,20,4),
(99,999,1,999,9),
(2,200,3,1000,100),
(3,300,2,NULL,NULL);

-- Baseline result set(s)
select * from (
with ssr as
 (select s_store_id,
        sum(sales_price) as sales,
        sum(profit) as profit,
        sum(return_amt) as returns,
        sum(net_loss) as profit_loss
 from
  ( select  ss_store_sk as store_sk,
            ss_sold_date_sk  as date_sk,
            ss_ext_sales_price as sales_price,
            ss_net_profit as profit,
            cast(0 as decimal(7,2)) as return_amt,
            cast(0 as decimal(7,2)) as net_loss
    from store_sales
    union all
    select sr_store_sk as store_sk,
           sr_returned_date_sk as date_sk,
           cast(0 as decimal(7,2)) as sales_price,
           cast(0 as decimal(7,2)) as profit,
           sr_return_amt as return_amt,
           sr_net_loss as net_loss
    from store_returns
   ) salesreturns,
     date_dim,
     store
 where date_sk = d_date_sk
       and d_date between cast('1998-08-28' as date) 
                  and (cast('1998-08-28' as date) +  interval 14 day)
       and store_sk = s_store_sk
 group by s_store_id)
 ,
 csr as
 (select cp_catalog_page_id,
        sum(sales_price) as sales,
        sum(profit) as profit,
        sum(return_amt) as returns,
        sum(net_loss) as profit_loss
 from
  ( select  cs_catalog_page_sk as page_sk,
            cs_sold_date_sk  as date_sk,
            cs_ext_sales_price as sales_price,
            cs_net_profit as profit,
            cast(0 as decimal(7,2)) as return_amt,
            cast(0 as decimal(7,2)) as net_loss
    from catalog_sales
    union all
    select cr_catalog_page_sk as page_sk,
           cr_returned_date_sk as date_sk,
           cast(0 as decimal(7,2)) as sales_price,
           cast(0 as decimal(7,2)) as profit,
           cr_return_amount as return_amt,
           cr_net_loss as net_loss
    from catalog_returns
   ) salesreturns,
     date_dim,
     catalog_page
 where date_sk = d_date_sk
       and d_date between cast('1998-08-28' as date)
                  and (cast('1998-08-28' as date) +  interval 14 day)
       and page_sk = cp_catalog_page_sk
 group by cp_catalog_page_id)
 ,
 wsr as
 (select web_site_id,
        sum(sales_price) as sales,
        sum(profit) as profit,
        sum(return_amt) as returns,
        sum(net_loss) as profit_loss
 from
  ( select  ws_web_site_sk as wsr_web_site_sk,
            ws_sold_date_sk  as date_sk,
            ws_ext_sales_price as sales_price,
            ws_net_profit as profit,
            cast(0 as decimal(7,2)) as return_amt,
            cast(0 as decimal(7,2)) as net_loss
    from web_sales
    union all
    select ws_web_site_sk as wsr_web_site_sk,
           wr_returned_date_sk as date_sk,
           cast(0 as decimal(7,2)) as sales_price,
           cast(0 as decimal(7,2)) as profit,
           wr_return_amt as return_amt,
           wr_net_loss as net_loss
    from web_returns left outer join web_sales on
         ( wr_item_sk = ws_item_sk
           and wr_order_number = ws_order_number)
   ) salesreturns,
     date_dim,
     web_site
 where date_sk = d_date_sk
       and d_date between cast('1998-08-28' as date)
                  and (cast('1998-08-28' as date) +  interval 14 day)
       and wsr_web_site_sk = web_site_sk
 group by web_site_id)
  select  channel
        , id
        , sum(sales) as sales
        , sum(returns) as returns
        , sum(profit) as profit
 from 
 (select 'store channel' as channel
        , 'store' || s_store_id as id
        , sales
        , returns
        , (profit - profit_loss) as profit
 from   ssr
 union all
 select 'catalog channel' as channel
        , 'catalog_page' || cp_catalog_page_id as id
        , sales
        , returns
        , (profit - profit_loss) as profit
 from  csr
 union all
 select 'web channel' as channel
        , 'web_site' || web_site_id as id
        , sales
        , returns
        , (profit - profit_loss) as profit
 from   wsr
 ) x
 group by channel, id with rollup
) tpcds_rollup
order by channel
         ,id
 limit 100;

-- Candidate result set(s)
select * from (
with ssr as
 (select s_store_id,
        sum(sales_price) as sales,
        sum(profit) as profit,
        sum(return_amt) as returns,
        sum(net_loss) as profit_loss
 from
  ( select  ss_store_sk as store_sk,
            ss_sold_date_sk  as date_sk,
            ss_ext_sales_price as sales_price,
            ss_net_profit as profit,
            cast(0 as decimal(7,2)) as return_amt,
            cast(0 as decimal(7,2)) as net_loss
    from store_sales
    JOIN date_dim filtered_date ON ss_sold_date_sk = filtered_date.d_date_sk
    WHERE filtered_date.d_date BETWEEN CAST('1998-08-28' AS DATE) AND (CAST('1998-08-28' AS DATE) + INTERVAL 14 DAY)
    union all
    select sr_store_sk as store_sk,
           sr_returned_date_sk as date_sk,
           cast(0 as decimal(7,2)) as sales_price,
           cast(0 as decimal(7,2)) as profit,
           sr_return_amt as return_amt,
           sr_net_loss as net_loss
    from store_returns
    JOIN date_dim filtered_date ON sr_returned_date_sk = filtered_date.d_date_sk
    WHERE filtered_date.d_date BETWEEN CAST('1998-08-28' AS DATE) AND (CAST('1998-08-28' AS DATE) + INTERVAL 14 DAY)
   ) salesreturns,
     date_dim,
     store
 where date_sk = d_date_sk
       and d_date between cast('1998-08-28' as date) 
                  and (cast('1998-08-28' as date) +  interval 14 day)
       and store_sk = s_store_sk
 group by s_store_id)
 ,
 csr as
 (select cp_catalog_page_id,
        sum(sales_price) as sales,
        sum(profit) as profit,
        sum(return_amt) as returns,
        sum(net_loss) as profit_loss
 from
  ( select  cs_catalog_page_sk as page_sk,
            cs_sold_date_sk  as date_sk,
            cs_ext_sales_price as sales_price,
            cs_net_profit as profit,
            cast(0 as decimal(7,2)) as return_amt,
            cast(0 as decimal(7,2)) as net_loss
    from catalog_sales
    JOIN date_dim filtered_date ON cs_sold_date_sk = filtered_date.d_date_sk
    WHERE filtered_date.d_date BETWEEN CAST('1998-08-28' AS DATE) AND (CAST('1998-08-28' AS DATE) + INTERVAL 14 DAY)
    union all
    select cr_catalog_page_sk as page_sk,
           cr_returned_date_sk as date_sk,
           cast(0 as decimal(7,2)) as sales_price,
           cast(0 as decimal(7,2)) as profit,
           cr_return_amount as return_amt,
           cr_net_loss as net_loss
    from catalog_returns
    JOIN date_dim filtered_date ON cr_returned_date_sk = filtered_date.d_date_sk
    WHERE filtered_date.d_date BETWEEN CAST('1998-08-28' AS DATE) AND (CAST('1998-08-28' AS DATE) + INTERVAL 14 DAY)
   ) salesreturns,
     date_dim,
     catalog_page
 where date_sk = d_date_sk
       and d_date between cast('1998-08-28' as date)
                  and (cast('1998-08-28' as date) +  interval 14 day)
       and page_sk = cp_catalog_page_sk
 group by cp_catalog_page_id)
 ,
 wsr as
 (select web_site_id,
        sum(sales_price) as sales,
        sum(profit) as profit,
        sum(return_amt) as returns,
        sum(net_loss) as profit_loss
 from
  ( select  ws_web_site_sk as wsr_web_site_sk,
            ws_sold_date_sk  as date_sk,
            ws_ext_sales_price as sales_price,
            ws_net_profit as profit,
            cast(0 as decimal(7,2)) as return_amt,
            cast(0 as decimal(7,2)) as net_loss
    from web_sales
    JOIN date_dim filtered_date ON ws_sold_date_sk = filtered_date.d_date_sk
    WHERE filtered_date.d_date BETWEEN CAST('1998-08-28' AS DATE) AND (CAST('1998-08-28' AS DATE) + INTERVAL 14 DAY)
    union all
    select ws_web_site_sk as wsr_web_site_sk,
           wr_returned_date_sk as date_sk,
           cast(0 as decimal(7,2)) as sales_price,
           cast(0 as decimal(7,2)) as profit,
           wr_return_amt as return_amt,
           wr_net_loss as net_loss
    from web_returns left outer join web_sales on
         ( wr_item_sk = ws_item_sk
           and wr_order_number = ws_order_number)
    JOIN date_dim filtered_date ON wr_returned_date_sk = filtered_date.d_date_sk
    WHERE filtered_date.d_date BETWEEN CAST('1998-08-28' AS DATE) AND (CAST('1998-08-28' AS DATE) + INTERVAL 14 DAY)
   ) salesreturns,
     date_dim,
     web_site
 where date_sk = d_date_sk
       and d_date between cast('1998-08-28' as date)
                  and (cast('1998-08-28' as date) +  interval 14 day)
       and wsr_web_site_sk = web_site_sk
 group by web_site_id)
  select  channel
        , id
        , sum(sales) as sales
        , sum(returns) as returns
        , sum(profit) as profit
 from 
 (select 'store channel' as channel
        , 'store' || s_store_id as id
        , sales
        , returns
        , (profit - profit_loss) as profit
 from   ssr
 union all
 select 'catalog channel' as channel
        , 'catalog_page' || cp_catalog_page_id as id
        , sales
        , returns
        , (profit - profit_loss) as profit
 from  csr
 union all
 select 'web channel' as channel
        , 'web_site' || web_site_id as id
        , sales
        , returns
        , (profit - profit_loss) as profit
 from   wsr
 ) x
 group by channel, id with rollup
) tpcds_rollup
order by channel
         ,id
 limit 100;

