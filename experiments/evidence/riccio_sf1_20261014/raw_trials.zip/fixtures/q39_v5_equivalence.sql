-- Synthetic equivalence fixture; temporary tables shadow the source tables for this session only.
CREATE TEMPORARY TABLE date_dim (d_date_sk BIGINT PRIMARY KEY,d_year BIGINT,d_moy BIGINT);
INSERT INTO date_dim VALUES
(1,1998,4),
(2,1998,4),
(3,1998,4),
(4,1998,4),
(5,1998,5),
(6,1998,5),
(7,1998,5),
(8,1998,5),
(9,1999,4);
CREATE TEMPORARY TABLE warehouse (w_warehouse_sk BIGINT PRIMARY KEY,w_warehouse_name VARCHAR(20));
INSERT INTO warehouse VALUES
(1,'Same name'),
(2,'Same name');
CREATE TEMPORARY TABLE item (i_item_sk BIGINT PRIMARY KEY);
INSERT INTO item VALUES
(1),
(2),
(3),
(4),
(5),
(6);
CREATE TEMPORARY TABLE inventory (inv_date_sk BIGINT,inv_item_sk BIGINT,inv_warehouse_sk BIGINT,inv_quantity_on_hand BIGINT,PRIMARY KEY(inv_date_sk,inv_item_sk,inv_warehouse_sk));
INSERT INTO inventory VALUES
(1,1,1,0),
(2,1,1,0),
(3,1,1,0),
(4,1,1,100),
(5,1,1,0),
(6,1,1,0),
(7,1,1,0),
(8,1,1,80),
(1,2,1,0),
(2,2,1,0),
(3,2,1,10),
(4,2,1,30),
(5,2,1,0),
(6,2,1,0),
(7,2,1,0),
(8,2,1,40),
(1,3,1,0),
(2,3,1,0),
(3,3,1,0),
(4,3,1,100),
(1,4,1,0),
(2,4,1,0),
(3,4,1,0),
(4,4,1,0),
(5,4,1,0),
(6,4,1,0),
(7,4,1,0),
(8,4,1,0),
(1,5,1,1),
(5,5,1,1),
(1,6,1,NULL),
(2,6,1,NULL),
(3,6,1,NULL),
(4,6,1,NULL),
(5,6,1,NULL),
(6,6,1,NULL),
(7,6,1,NULL),
(8,6,1,NULL),
(1,1,2,0),
(2,1,2,0),
(3,1,2,0),
(4,1,2,20),
(5,1,2,0),
(6,1,2,0),
(7,1,2,0),
(8,1,2,40),
(1,99,1,0),
(2,99,1,0),
(3,99,1,0),
(4,99,1,100),
(5,99,1,0),
(6,99,1,0),
(7,99,1,0),
(8,99,1,80),
(1,1,99,0),
(2,1,99,0),
(3,1,99,0),
(4,1,99,100),
(5,1,99,0),
(6,1,99,0),
(7,1,99,0),
(8,1,99,80),
(9,1,1,9999);

-- Baseline result set(s)
with inv as
(select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
       ,stdev,mean, case mean when 0 then null else stdev/mean end cov
 from(select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
            ,stddev_samp(inv_quantity_on_hand) stdev,avg(inv_quantity_on_hand) mean
      from inventory
          ,item
          ,warehouse
          ,date_dim
      where inv_item_sk = i_item_sk
        and inv_warehouse_sk = w_warehouse_sk
        and inv_date_sk = d_date_sk
        and d_year =1998
      group by w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy) foo
 where case mean when 0 then 0 else stdev/mean end > 1)
select inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean, inv1.cov
        ,inv2.w_warehouse_sk,inv2.i_item_sk,inv2.d_moy,inv2.mean, inv2.cov
from inv inv1,inv inv2
where inv1.i_item_sk = inv2.i_item_sk
  and inv1.w_warehouse_sk =  inv2.w_warehouse_sk
  and inv1.d_moy=4
  and inv2.d_moy=4+1
order by inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean,inv1.cov
        ,inv2.d_moy,inv2.mean, inv2.cov
;

with inv as
(select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
       ,stdev,mean, case mean when 0 then null else stdev/mean end cov
 from(select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
            ,stddev_samp(inv_quantity_on_hand) stdev,avg(inv_quantity_on_hand) mean
      from inventory
          ,item
          ,warehouse
          ,date_dim
      where inv_item_sk = i_item_sk
        and inv_warehouse_sk = w_warehouse_sk
        and inv_date_sk = d_date_sk
        and d_year =1998
      group by w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy) foo
 where case mean when 0 then 0 else stdev/mean end > 1)
select inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean, inv1.cov
        ,inv2.w_warehouse_sk,inv2.i_item_sk,inv2.d_moy,inv2.mean, inv2.cov
from inv inv1,inv inv2
where inv1.i_item_sk = inv2.i_item_sk
  and inv1.w_warehouse_sk =  inv2.w_warehouse_sk
  and inv1.d_moy=4
  and inv2.d_moy=4+1
  and inv1.cov > 1.5
order by inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean,inv1.cov
        ,inv2.d_moy,inv2.mean, inv2.cov
;

-- Candidate result set(s)
-- Keep the clustered date-leading inventory access path available in every profile.
-- Late dimension lookups while retaining two independent SELECT statements.
-- No temporary results are shared between their snapshots.
WITH inv_raw AS (
    SELECT inv_warehouse_sk,inv_item_sk,d_moy,
           STDDEV_SAMP(inv_quantity_on_hand) AS stdev,
           AVG(inv_quantity_on_hand) AS mean
    FROM inventory FORCE INDEX (PRIMARY)
    JOIN date_dim ON inv_date_sk = d_date_sk
    WHERE d_year = 1998 AND d_moy IN (4,5)
    GROUP BY inv_warehouse_sk,inv_item_sk,d_moy
),
inv AS (
    SELECT w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy,stdev,mean,
           CASE mean WHEN 0 THEN NULL ELSE stdev/mean END AS cov
    FROM inv_raw
    JOIN item ON inv_item_sk = i_item_sk
    JOIN warehouse ON inv_warehouse_sk = w_warehouse_sk
    WHERE CASE mean WHEN 0 THEN 0 ELSE stdev/mean END > 1
)
select inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean, inv1.cov
        ,inv2.w_warehouse_sk,inv2.i_item_sk,inv2.d_moy,inv2.mean, inv2.cov
from inv inv1,inv inv2
where inv1.i_item_sk = inv2.i_item_sk
  and inv1.w_warehouse_sk =  inv2.w_warehouse_sk
  and inv1.d_moy=4
  and inv2.d_moy=4+1
order by inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean,inv1.cov
        ,inv2.d_moy,inv2.mean, inv2.cov
;

WITH inv_raw AS (
    SELECT inv_warehouse_sk,inv_item_sk,d_moy,
           STDDEV_SAMP(inv_quantity_on_hand) AS stdev,
           AVG(inv_quantity_on_hand) AS mean
    FROM inventory FORCE INDEX (PRIMARY)
    JOIN date_dim ON inv_date_sk = d_date_sk
    WHERE d_year = 1998 AND d_moy IN (4,5)
    GROUP BY inv_warehouse_sk,inv_item_sk,d_moy
),
inv AS (
    SELECT w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy,stdev,mean,
           CASE mean WHEN 0 THEN NULL ELSE stdev/mean END AS cov
    FROM inv_raw
    JOIN item ON inv_item_sk = i_item_sk
    JOIN warehouse ON inv_warehouse_sk = w_warehouse_sk
    WHERE CASE mean WHEN 0 THEN 0 ELSE stdev/mean END > 1
)
select inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean, inv1.cov
        ,inv2.w_warehouse_sk,inv2.i_item_sk,inv2.d_moy,inv2.mean, inv2.cov
from inv inv1,inv inv2
where inv1.i_item_sk = inv2.i_item_sk
  and inv1.w_warehouse_sk =  inv2.w_warehouse_sk
  and inv1.d_moy=4
  and inv2.d_moy=4+1
  and inv1.cov > 1.5
order by inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean,inv1.cov
        ,inv2.d_moy,inv2.mean, inv2.cov
;

