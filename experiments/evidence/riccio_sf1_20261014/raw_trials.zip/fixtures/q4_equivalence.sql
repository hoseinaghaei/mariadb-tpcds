-- Synthetic equivalence fixture; temporary tables shadow the source tables for this session only.
CREATE TEMPORARY TABLE date_dim (d_date_sk BIGINT PRIMARY KEY,d_year BIGINT);
INSERT INTO date_dim VALUES
(1,2001),
(2,2002),
(3,2000);
CREATE TEMPORARY TABLE customer (c_customer_sk BIGINT PRIMARY KEY,c_customer_id CHAR(16) UNIQUE,c_first_name CHAR(20),c_last_name CHAR(30),c_preferred_cust_flag CHAR(1),c_birth_country VARCHAR(20),c_login VARCHAR(13),c_email_address VARCHAR(50));
INSERT INTO customer VALUES
(1,'AAAAAAAA00000001',NULL,'Last1','Y','Italy',NULL,'person1@example.test'),
(2,'AAAAAAAA00000002','Name2','Last2','Y','Italy','login2','person2@example.test'),
(3,'AAAAAAAA00000003','Name3','Last3','Y','Italy','login3','person3@example.test'),
(4,'AAAAAAAA00000004','Name4','Last4','Y','Italy','login4','person4@example.test'),
(5,'AAAAAAAA00000005','Name5','Last5','Y','Italy','login5','person5@example.test');
CREATE TEMPORARY TABLE store_sales (ss_customer_sk BIGINT,ss_sold_date_sk BIGINT,ss_ext_list_price DECIMAL(7,2),ss_ext_wholesale_cost DECIMAL(7,2),ss_ext_discount_amt DECIMAL(7,2),ss_ext_sales_price DECIMAL(7,2));
INSERT INTO store_sales VALUES
(1,1,0,0,0,200),
(1,2,0,0,0,400),
(2,1,0,0,0,200),
(2,2,0,0,0,400),
(3,1,0,0,0,200),
(4,1,0,0,0,200),
(4,2,0,0,0,400),
(5,1,0,0,0,0),
(5,2,0,0,0,400),
(1,3,0,0,0,9999),
(99,1,0,0,0,200),
(99,2,0,0,0,800);
CREATE TEMPORARY TABLE catalog_sales (cs_bill_customer_sk BIGINT,cs_sold_date_sk BIGINT,cs_ext_list_price DECIMAL(7,2),cs_ext_wholesale_cost DECIMAL(7,2),cs_ext_discount_amt DECIMAL(7,2),cs_ext_sales_price DECIMAL(7,2));
INSERT INTO catalog_sales VALUES
(1,1,0,0,0,200),
(1,2,0,0,0,600),
(2,1,0,0,0,200),
(2,2,0,0,0,300),
(3,1,0,0,0,200),
(3,2,0,0,0,600),
(4,1,0,0,0,200),
(4,2,0,0,0,NULL),
(5,1,0,0,0,200),
(5,2,0,0,0,600),
(1,3,0,0,0,9999),
(99,1,0,0,0,200),
(99,2,0,0,0,800);
CREATE TEMPORARY TABLE web_sales (ws_bill_customer_sk BIGINT,ws_sold_date_sk BIGINT,ws_ext_list_price DECIMAL(7,2),ws_ext_wholesale_cost DECIMAL(7,2),ws_ext_discount_amt DECIMAL(7,2),ws_ext_sales_price DECIMAL(7,2));
INSERT INTO web_sales VALUES
(1,1,0,0,0,200),
(1,2,0,0,0,400),
(2,1,0,0,0,200),
(2,2,0,0,0,280),
(3,1,0,0,0,200),
(3,2,0,0,0,400),
(4,1,0,0,0,200),
(4,2,0,0,0,400),
(5,1,0,0,0,200),
(5,2,0,0,0,400),
(1,3,0,0,0,9999),
(99,1,0,0,0,200),
(99,2,0,0,0,800);

-- Baseline result set(s)
with year_total as (
 select c_customer_id customer_id
       ,c_first_name customer_first_name
       ,c_last_name customer_last_name
       ,c_preferred_cust_flag customer_preferred_cust_flag
       ,c_birth_country customer_birth_country
       ,c_login customer_login
       ,c_email_address customer_email_address
       ,d_year dyear
       ,sum(((ss_ext_list_price-ss_ext_wholesale_cost-ss_ext_discount_amt)+ss_ext_sales_price)/2) year_total
       ,'s' sale_type
 from customer
     ,store_sales
     ,date_dim
 where c_customer_sk = ss_customer_sk
   and ss_sold_date_sk = d_date_sk
 group by c_customer_id
         ,c_first_name
         ,c_last_name
         ,c_preferred_cust_flag
         ,c_birth_country
         ,c_login
         ,c_email_address
         ,d_year
 union all
 select c_customer_id customer_id
       ,c_first_name customer_first_name
       ,c_last_name customer_last_name
       ,c_preferred_cust_flag customer_preferred_cust_flag
       ,c_birth_country customer_birth_country
       ,c_login customer_login
       ,c_email_address customer_email_address
       ,d_year dyear
       ,sum((((cs_ext_list_price-cs_ext_wholesale_cost-cs_ext_discount_amt)+cs_ext_sales_price)/2) ) year_total
       ,'c' sale_type
 from customer
     ,catalog_sales
     ,date_dim
 where c_customer_sk = cs_bill_customer_sk
   and cs_sold_date_sk = d_date_sk
 group by c_customer_id
         ,c_first_name
         ,c_last_name
         ,c_preferred_cust_flag
         ,c_birth_country
         ,c_login
         ,c_email_address
         ,d_year
union all
 select c_customer_id customer_id
       ,c_first_name customer_first_name
       ,c_last_name customer_last_name
       ,c_preferred_cust_flag customer_preferred_cust_flag
       ,c_birth_country customer_birth_country
       ,c_login customer_login
       ,c_email_address customer_email_address
       ,d_year dyear
       ,sum((((ws_ext_list_price-ws_ext_wholesale_cost-ws_ext_discount_amt)+ws_ext_sales_price)/2) ) year_total
       ,'w' sale_type
 from customer
     ,web_sales
     ,date_dim
 where c_customer_sk = ws_bill_customer_sk
   and ws_sold_date_sk = d_date_sk
 group by c_customer_id
         ,c_first_name
         ,c_last_name
         ,c_preferred_cust_flag
         ,c_birth_country
         ,c_login
         ,c_email_address
         ,d_year
         )
  select  
                  t_s_secyear.customer_id
                 ,t_s_secyear.customer_first_name
                 ,t_s_secyear.customer_last_name
                 ,t_s_secyear.customer_login
 from year_total t_s_firstyear
     ,year_total t_s_secyear
     ,year_total t_c_firstyear
     ,year_total t_c_secyear
     ,year_total t_w_firstyear
     ,year_total t_w_secyear
 where t_s_secyear.customer_id = t_s_firstyear.customer_id
   and t_s_firstyear.customer_id = t_c_secyear.customer_id
   and t_s_firstyear.customer_id = t_c_firstyear.customer_id
   and t_s_firstyear.customer_id = t_w_firstyear.customer_id
   and t_s_firstyear.customer_id = t_w_secyear.customer_id
   and t_s_firstyear.sale_type = 's'
   and t_c_firstyear.sale_type = 'c'
   and t_w_firstyear.sale_type = 'w'
   and t_s_secyear.sale_type = 's'
   and t_c_secyear.sale_type = 'c'
   and t_w_secyear.sale_type = 'w'
   and t_s_firstyear.dyear =  2001
   and t_s_secyear.dyear = 2001+1
   and t_c_firstyear.dyear =  2001
   and t_c_secyear.dyear =  2001+1
   and t_w_firstyear.dyear = 2001
   and t_w_secyear.dyear = 2001+1
   and t_s_firstyear.year_total > 0
   and t_c_firstyear.year_total > 0
   and t_w_firstyear.year_total > 0
   and case when t_c_firstyear.year_total > 0 then t_c_secyear.year_total / t_c_firstyear.year_total else null end
           > case when t_s_firstyear.year_total > 0 then t_s_secyear.year_total / t_s_firstyear.year_total else null end
   and case when t_c_firstyear.year_total > 0 then t_c_secyear.year_total / t_c_firstyear.year_total else null end
           > case when t_w_firstyear.year_total > 0 then t_w_secyear.year_total / t_w_firstyear.year_total else null end
 order by t_s_secyear.customer_id
         ,t_s_secyear.customer_first_name
         ,t_s_secyear.customer_last_name
         ,t_s_secyear.customer_login
limit 100;

-- Candidate result set(s)
-- Requires unique customer.c_customer_id; validate that assumption separately.
-- Aggregate the two years once per channel using narrow surrogate keys.
-- Keep both year groups, NULL totals, positive denominators and exact arithmetic.
WITH s AS (
    SELECT ss_customer_sk AS customer_sk,
           SUM(CASE WHEN d_year = 2001 THEN
               ((ss_ext_list_price-ss_ext_wholesale_cost-ss_ext_discount_amt)+ss_ext_sales_price)/2
           END) AS y1,
           SUM(CASE WHEN d_year = 2002 THEN
               ((ss_ext_list_price-ss_ext_wholesale_cost-ss_ext_discount_amt)+ss_ext_sales_price)/2
           END) AS y2
    FROM store_sales
    JOIN date_dim ON ss_sold_date_sk = d_date_sk
    WHERE d_year IN (2001,2002)
    GROUP BY ss_customer_sk
    HAVING COUNT(DISTINCT d_year) = 2
),
c AS (
    SELECT cs_bill_customer_sk AS customer_sk,
           SUM(CASE WHEN d_year = 2001 THEN
               ((cs_ext_list_price-cs_ext_wholesale_cost-cs_ext_discount_amt)+cs_ext_sales_price)/2
           END) AS y1,
           SUM(CASE WHEN d_year = 2002 THEN
               ((cs_ext_list_price-cs_ext_wholesale_cost-cs_ext_discount_amt)+cs_ext_sales_price)/2
           END) AS y2
    FROM catalog_sales
    JOIN date_dim ON cs_sold_date_sk = d_date_sk
    WHERE d_year IN (2001,2002)
    GROUP BY cs_bill_customer_sk
    HAVING COUNT(DISTINCT d_year) = 2
),
w AS (
    SELECT ws_bill_customer_sk AS customer_sk,
           SUM(CASE WHEN d_year = 2001 THEN
               ((ws_ext_list_price-ws_ext_wholesale_cost-ws_ext_discount_amt)+ws_ext_sales_price)/2
           END) AS y1,
           SUM(CASE WHEN d_year = 2002 THEN
               ((ws_ext_list_price-ws_ext_wholesale_cost-ws_ext_discount_amt)+ws_ext_sales_price)/2
           END) AS y2
    FROM web_sales
    JOIN date_dim ON ws_sold_date_sk = d_date_sk
    WHERE d_year IN (2001,2002)
    GROUP BY ws_bill_customer_sk
    HAVING COUNT(DISTINCT d_year) = 2
)
SELECT customer.c_customer_id AS customer_id,
       customer.c_first_name AS customer_first_name,
       customer.c_last_name AS customer_last_name,
       customer.c_login AS customer_login
FROM s
JOIN c ON s.customer_sk = c.customer_sk
JOIN w ON s.customer_sk = w.customer_sk
JOIN customer ON customer.c_customer_sk = s.customer_sk
WHERE s.y1 > 0 AND c.y1 > 0 AND w.y1 > 0
  AND CASE WHEN c.y1 > 0 THEN c.y2/c.y1 ELSE NULL END
      > CASE WHEN s.y1 > 0 THEN s.y2/s.y1 ELSE NULL END
  AND CASE WHEN c.y1 > 0 THEN c.y2/c.y1 ELSE NULL END
      > CASE WHEN w.y1 > 0 THEN w.y2/w.y1 ELSE NULL END
ORDER BY customer_id, customer_first_name, customer_last_name, customer_login
LIMIT 100;

