WITH date_dim AS (
SELECT CAST('10' AS SIGNED) AS d_date_sk, CAST('1176' AS SIGNED) AS d_month_seq, CAST('1998' AS SIGNED) AS d_year, CAST('1' AS SIGNED) AS d_qoy, CAST('1' AS SIGNED) AS d_moy
UNION ALL
SELECT CAST('30' AS SIGNED) AS d_date_sk, CAST('1177' AS SIGNED) AS d_month_seq, CAST('1998' AS SIGNED) AS d_year, CAST('1' AS SIGNED) AS d_qoy, CAST('2' AS SIGNED) AS d_moy
UNION ALL
SELECT CAST('20' AS SIGNED) AS d_date_sk, CAST('1175' AS SIGNED) AS d_month_seq, CAST('1997' AS SIGNED) AS d_year, CAST('4' AS SIGNED) AS d_qoy, CAST('12' AS SIGNED) AS d_moy
UNION ALL
SELECT CAST('40' AS SIGNED) AS d_date_sk, CAST('1188' AS SIGNED) AS d_month_seq, CAST('1999' AS SIGNED) AS d_year, CAST('1' AS SIGNED) AS d_qoy, CAST('1' AS SIGNED) AS d_moy
),
item AS (
SELECT CAST('1' AS SIGNED) AS i_item_sk, CAST('A' AS CHAR(50)) AS i_category, CAST('Class' AS CHAR(50)) AS i_class, CAST('Brand' AS CHAR(50)) AS i_brand, CAST('Same' AS CHAR(50)) AS i_product_name
UNION ALL
SELECT CAST('2' AS SIGNED) AS i_item_sk, CAST('A' AS CHAR(50)) AS i_category, CAST('Class' AS CHAR(50)) AS i_class, CAST('Brand' AS CHAR(50)) AS i_brand, CAST('Same' AS CHAR(50)) AS i_product_name
UNION ALL
SELECT CAST('3' AS SIGNED) AS i_item_sk, CAST(NULL AS CHAR(50)) AS i_category, CAST(NULL AS CHAR(50)) AS i_class, CAST('B' AS CHAR(50)) AS i_brand, CAST('Null category' AS CHAR(50)) AS i_product_name
UNION ALL
SELECT CAST('4' AS SIGNED) AS i_item_sk, CAST('B' AS CHAR(50)) AS i_category, CAST('C' AS CHAR(50)) AS i_class, CAST(NULL AS CHAR(50)) AS i_brand, CAST('Other' AS CHAR(50)) AS i_product_name
),
store AS (
SELECT CAST('1' AS SIGNED) AS s_store_sk, CAST('SAME' AS CHAR(16)) AS s_store_id
UNION ALL
SELECT CAST('2' AS SIGNED) AS s_store_sk, CAST('SAME' AS CHAR(16)) AS s_store_id
UNION ALL
SELECT CAST('3' AS SIGNED) AS s_store_sk, CAST('OTHER' AS CHAR(16)) AS s_store_id
),
store_sales AS (
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('10' AS DECIMAL(7,2)) AS ss_sales_price, CAST('2' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('5' AS DECIMAL(7,2)) AS ss_sales_price, CAST('1' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('2' AS SIGNED) AS ss_item_sk, CAST('2' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('25' AS DECIMAL(7,2)) AS ss_sales_price, CAST('1' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('-5' AS DECIMAL(7,2)) AS ss_sales_price, CAST('2' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('3' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST(NULL AS DECIMAL(7,2)) AS ss_sales_price, CAST('4' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('3' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('4' AS DECIMAL(7,2)) AS ss_sales_price, CAST(NULL AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('4' AS SIGNED) AS ss_item_sk, CAST('3' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_sales_price, CAST('2' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('4' AS SIGNED) AS ss_item_sk, CAST('3' AS SIGNED) AS ss_store_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('20' AS DECIMAL(7,2)) AS ss_sales_price, CAST('1' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('20' AS SIGNED) AS ss_sold_date_sk, CAST('99999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('40' AS SIGNED) AS ss_sold_date_sk, CAST('99999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('99' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('99' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST(NULL AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('999' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
)
select * from (
select  *
from (select i_category
            ,i_class
            ,i_brand
            ,i_product_name
            ,d_year
            ,d_qoy
            ,d_moy
            ,s_store_id
            ,sumsales
            ,rank() over (partition by i_category order by sumsales desc) rk
      from (select i_category
                  ,i_class
                  ,i_brand
                  ,i_product_name
                  ,d_year
                  ,d_qoy
                  ,d_moy
                  ,s_store_id
                  ,sum(coalesce(ss_sales_price*ss_quantity,0)) sumsales
            from store_sales
                ,date_dim
                ,store
                ,item
       where  ss_sold_date_sk=d_date_sk
          and ss_item_sk=i_item_sk
          and ss_store_sk = s_store_sk
          and d_month_seq between 1176 and 1176+11
       group by i_category, i_class, i_brand, i_product_name, d_year, d_qoy, d_moy,s_store_id with rollup)dw1) dw2
where rk <= 100
) tpcds_rollup
order by i_category
        ,i_class
        ,i_brand
        ,i_product_name
        ,d_year
        ,d_qoy
        ,d_moy
        ,s_store_id
        ,sumsales
        ,rk
limit 100;
