SET SESSION max_statement_time=20;
SELECT * FROM dbgen_version;
SELECT COUNT(*) AS customers, COUNT(DISTINCT c_customer_id) AS distinct_ids,
 SUM(c_customer_id IS NULL) AS null_ids FROM customer;
SELECT d_year,MIN(d_date_sk) AS lo,MAX(d_date_sk) AS hi,COUNT(*) AS dates
 FROM date_dim WHERE d_year IN (2001,2002) GROUP BY d_year;
SELECT COUNT(DISTINCT CONCAT(TABLE_NAME, ':', INDEX_NAME)) AS total_indexes
 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE();
