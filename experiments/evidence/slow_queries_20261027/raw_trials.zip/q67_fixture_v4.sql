WITH date_dim AS (
SELECT CAST('10' AS SIGNED) AS d_date_sk, CAST('1176' AS SIGNED) AS d_month_seq, CAST('1998' AS SIGNED) AS d_year, CAST('1' AS SIGNED) AS d_qoy, CAST('1' AS SIGNED) AS d_moy
UNION ALL
SELECT CAST('30' AS SIGNED) AS d_date_sk, CAST('1177' AS SIGNED) AS d_month_seq, CAST('1998' AS SIGNED) AS d_year, CAST('1' AS SIGNED) AS d_qoy, CAST('2' AS SIGNED) AS d_moy
UNION ALL
SELECT CAST('20' AS SIGNED) AS d_date_sk, CAST('1175' AS SIGNED) AS d_month_seq, CAST('1997' AS SIGNED) AS d_year, CAST('4' AS SIGNED) AS d_qoy, CAST('12' AS SIGNED) AS d_moy
UNION ALL
SELECT CAST('40' AS SIGNED) AS d_date_sk, CAST('1188' AS SIGNED) AS d_month_seq, CAST('1999' AS SIGNED) AS d_year, CAST('1' AS SIGNED) AS d_qoy, CAST('1' AS SIGNED) AS d_moy
),
item AS (
SELECT CAST('1' AS SIGNED) AS i_item_sk, CAST('A' AS CHAR(50)) AS i_category, CAST('Class' AS CHAR(50)) AS i_class, CAST('Brand' AS CHAR(50)) AS i_brand, CAST('Same' AS CHAR(50)) AS i_product_name
UNION ALL
SELECT CAST('2' AS SIGNED) AS i_item_sk, CAST('A' AS CHAR(50)) AS i_category, CAST('Class' AS CHAR(50)) AS i_class, CAST('Brand' AS CHAR(50)) AS i_brand, CAST('Same' AS CHAR(50)) AS i_product_name
UNION ALL
SELECT CAST('3' AS SIGNED) AS i_item_sk, CAST(NULL AS CHAR(50)) AS i_category, CAST(NULL AS CHAR(50)) AS i_class, CAST('B' AS CHAR(50)) AS i_brand, CAST('Null category' AS CHAR(50)) AS i_product_name
UNION ALL
SELECT CAST('4' AS SIGNED) AS i_item_sk, CAST('B' AS CHAR(50)) AS i_category, CAST('C' AS CHAR(50)) AS i_class, CAST(NULL AS CHAR(50)) AS i_brand, CAST('Other' AS CHAR(50)) AS i_product_name
),
store AS (
SELECT CAST('1' AS SIGNED) AS s_store_sk, CAST('SAME' AS CHAR(16)) AS s_store_id
UNION ALL
SELECT CAST('2' AS SIGNED) AS s_store_sk, CAST('SAME' AS CHAR(16)) AS s_store_id
UNION ALL
SELECT CAST('3' AS SIGNED) AS s_store_sk, CAST('OTHER' AS CHAR(16)) AS s_store_id
),
store_sales AS (
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('10' AS DECIMAL(7,2)) AS ss_sales_price, CAST('2' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('5' AS DECIMAL(7,2)) AS ss_sales_price, CAST('1' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('2' AS SIGNED) AS ss_item_sk, CAST('2' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('25' AS DECIMAL(7,2)) AS ss_sales_price, CAST('1' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('-5' AS DECIMAL(7,2)) AS ss_sales_price, CAST('2' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('3' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST(NULL AS DECIMAL(7,2)) AS ss_sales_price, CAST('4' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('3' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('4' AS DECIMAL(7,2)) AS ss_sales_price, CAST(NULL AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('4' AS SIGNED) AS ss_item_sk, CAST('3' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_sales_price, CAST('2' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('4' AS SIGNED) AS ss_item_sk, CAST('3' AS SIGNED) AS ss_store_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('20' AS DECIMAL(7,2)) AS ss_sales_price, CAST('1' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('20' AS SIGNED) AS ss_sold_date_sk, CAST('99999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('40' AS SIGNED) AS ss_sold_date_sk, CAST('99999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('99' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('99' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST(NULL AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_item_sk, CAST('1' AS SIGNED) AS ss_store_sk, CAST('999' AS SIGNED) AS ss_sold_date_sk, CAST('999' AS DECIMAL(7,2)) AS ss_sales_price, CAST('9' AS SIGNED) AS ss_quantity
),
monthly AS (
    SELECT ss.ss_item_sk AS item_sk, ss.ss_store_sk AS store_sk,
           d.d_year, d.d_qoy, d.d_moy,
           SUM(COALESCE(ss.ss_sales_price * ss.ss_quantity, 0)) AS sales
    FROM store_sales ss
    JOIN date_dim d ON d.d_date_sk = ss.ss_sold_date_sk
    WHERE d.d_month_seq BETWEEN 1176 AND 1176+11
      AND ss.ss_sold_date_sk BETWEEN 10 AND 30
    GROUP BY ss.ss_item_sk, ss.ss_store_sk, d.d_year, d.d_qoy, d.d_moy
)
SELECT i_category, i_class, i_brand, i_product_name,
       d_year, d_qoy, d_moy, s_store_id, sumsales, rk
FROM (
    SELECT i_category, i_class, i_brand, i_product_name,
           d_year, d_qoy, d_moy, s_store_id, sumsales,
           RANK() OVER (PARTITION BY i_category ORDER BY sumsales DESC) AS rk
    FROM (
        SELECT i.i_category, i.i_class, i.i_brand, i.i_product_name,
               m.d_year, m.d_qoy, m.d_moy, s.s_store_id,
               SUM(m.sales) AS sumsales
        FROM monthly m
        JOIN item i  ON i.i_item_sk = m.item_sk
        JOIN store s ON s.s_store_sk = m.store_sk
        GROUP BY i.i_category, i.i_class, i.i_brand, i.i_product_name,
                 m.d_year, m.d_qoy, m.d_moy, s.s_store_id WITH ROLLUP
    ) dw1
) dw2
WHERE rk <= 100
ORDER BY i_category, i_class, i_brand, i_product_name,
         d_year, d_qoy, d_moy, s_store_id, sumsales, rk
LIMIT 100;
