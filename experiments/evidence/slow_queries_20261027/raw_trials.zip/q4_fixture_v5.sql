WITH date_dim AS (
SELECT CAST('10' AS SIGNED) AS d_date_sk, CAST('2001' AS SIGNED) AS d_year
UNION ALL
SELECT CAST('30' AS SIGNED) AS d_date_sk, CAST('2002' AS SIGNED) AS d_year
UNION ALL
SELECT CAST('20' AS SIGNED) AS d_date_sk, CAST('2000' AS SIGNED) AS d_year
UNION ALL
SELECT CAST('40' AS SIGNED) AS d_date_sk, CAST('2003' AS SIGNED) AS d_year
),
customer AS (
SELECT CAST('1' AS SIGNED) AS c_customer_sk, CAST('C001' AS CHAR(16)) AS c_customer_id, CAST(NULL AS CHAR(20)) AS c_first_name, CAST('L1' AS CHAR(30)) AS c_last_name, CAST(NULL AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('2' AS SIGNED) AS c_customer_sk, CAST('C002' AS CHAR(16)) AS c_customer_id, CAST('N2' AS CHAR(20)) AS c_first_name, CAST('L2' AS CHAR(30)) AS c_last_name, CAST('user2' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('3' AS SIGNED) AS c_customer_sk, CAST('C003' AS CHAR(16)) AS c_customer_id, CAST('N3' AS CHAR(20)) AS c_first_name, CAST('L3' AS CHAR(30)) AS c_last_name, CAST('user3' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('4' AS SIGNED) AS c_customer_sk, CAST('C004' AS CHAR(16)) AS c_customer_id, CAST('N4' AS CHAR(20)) AS c_first_name, CAST('L4' AS CHAR(30)) AS c_last_name, CAST('user4' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('5' AS SIGNED) AS c_customer_sk, CAST('C005' AS CHAR(16)) AS c_customer_id, CAST('N5' AS CHAR(20)) AS c_first_name, CAST('L5' AS CHAR(30)) AS c_last_name, CAST('user5' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('6' AS SIGNED) AS c_customer_sk, CAST('C006' AS CHAR(16)) AS c_customer_id, CAST('N6' AS CHAR(20)) AS c_first_name, CAST('L6' AS CHAR(30)) AS c_last_name, CAST('user6' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('7' AS SIGNED) AS c_customer_sk, CAST('C007' AS CHAR(16)) AS c_customer_id, CAST('N7' AS CHAR(20)) AS c_first_name, CAST('L7' AS CHAR(30)) AS c_last_name, CAST('user7' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('8' AS SIGNED) AS c_customer_sk, CAST('C008' AS CHAR(16)) AS c_customer_id, CAST('N8' AS CHAR(20)) AS c_first_name, CAST('L8' AS CHAR(30)) AS c_last_name, CAST('user8' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('9' AS SIGNED) AS c_customer_sk, CAST('C009' AS CHAR(16)) AS c_customer_id, CAST('N9' AS CHAR(20)) AS c_first_name, CAST('L9' AS CHAR(30)) AS c_last_name, CAST('user9' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('10' AS SIGNED) AS c_customer_sk, CAST('C010' AS CHAR(16)) AS c_customer_id, CAST('N10' AS CHAR(20)) AS c_first_name, CAST('L10' AS CHAR(30)) AS c_last_name, CAST('user10' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('11' AS SIGNED) AS c_customer_sk, CAST('C011' AS CHAR(16)) AS c_customer_id, CAST('N11' AS CHAR(20)) AS c_first_name, CAST('L11' AS CHAR(30)) AS c_last_name, CAST('user11' AS CHAR(13)) AS c_login
UNION ALL
SELECT CAST('12' AS SIGNED) AS c_customer_sk, CAST('C012' AS CHAR(16)) AS c_customer_id, CAST('N12' AS CHAR(20)) AS c_first_name, CAST('L12' AS CHAR(30)) AS c_last_name, CAST('user12' AS CHAR(13)) AS c_login
),
store_sales AS (
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('2' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('2' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('3' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('3' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST(NULL AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('4' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('4' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('5' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('0' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('5' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('6' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('6' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('7' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('-20' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('7' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('8' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('8' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('-400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('9' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('9' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('-400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('10' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('0.02' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('10' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('0.04' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('11' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('11' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('0' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('12' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('12' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('20' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST(NULL AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('20' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('40' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('99' AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('100' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('99' AS SIGNED) AS ss_customer_sk, CAST('30' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('800' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST(NULL AS SIGNED) AS ss_customer_sk, CAST('10' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('100' AS DECIMAL(7,2)) AS ss_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ss_customer_sk, CAST('999' AS SIGNED) AS ss_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ss_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ss_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ss_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS ss_ext_sales_price
),
catalog_sales AS (
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('2' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('2' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('300' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('3' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('3' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('4' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('5' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('5' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('6' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('6' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('7' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('7' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('8' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('8' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('-200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('9' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('9' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('0' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('10' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('0.02' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('10' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('0.06' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('11' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('11' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('12' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('12' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('600' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('20' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST(NULL AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('20' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('40' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('99' AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('100' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('99' AS SIGNED) AS cs_bill_customer_sk, CAST('30' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('800' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST(NULL AS SIGNED) AS cs_bill_customer_sk, CAST('10' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('100' AS DECIMAL(7,2)) AS cs_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS cs_bill_customer_sk, CAST('999' AS SIGNED) AS cs_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS cs_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS cs_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS cs_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS cs_ext_sales_price
),
web_sales AS (
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('2' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('2' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('3' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('3' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('4' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('4' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('5' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('5' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('6' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST(NULL AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('6' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('7' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('7' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('8' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('8' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('-400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('9' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('9' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('-400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('10' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('0.02' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('10' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('0.04' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('11' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('11' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('12' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('200' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('12' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('400' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('20' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST(NULL AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('20' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('40' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('99' AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('100' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('99' AS SIGNED) AS ws_bill_customer_sk, CAST('30' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('800' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST(NULL AS SIGNED) AS ws_bill_customer_sk, CAST('10' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('100' AS DECIMAL(7,2)) AS ws_ext_sales_price
UNION ALL
SELECT CAST('1' AS SIGNED) AS ws_bill_customer_sk, CAST('999' AS SIGNED) AS ws_sold_date_sk, CAST('0' AS DECIMAL(7,2)) AS ws_ext_list_price, CAST('0' AS DECIMAL(7,2)) AS ws_ext_wholesale_cost, CAST('0' AS DECIMAL(7,2)) AS ws_ext_discount_amt, CAST('999999' AS DECIMAL(7,2)) AS ws_ext_sales_price
),
date_bounds AS (
    SELECT MIN(d_date_sk) AS lo, MAX(d_date_sk) AS hi
    FROM date_dim WHERE d_year IN (2001,2002)
), s AS (
    SELECT ss_customer_sk AS customer_sk,
           SUM(CASE WHEN d_year = 2001 THEN
               ((ss_ext_list_price-ss_ext_wholesale_cost-ss_ext_discount_amt)+ss_ext_sales_price)/2
           END) AS y1,
           SUM(CASE WHEN d_year = 2002 THEN
               ((ss_ext_list_price-ss_ext_wholesale_cost-ss_ext_discount_amt)+ss_ext_sales_price)/2
           END) AS y2
    FROM store_sales
    JOIN date_dim ON ss_sold_date_sk = d_date_sk
    WHERE d_year IN (2001,2002)
      AND ss_sold_date_sk BETWEEN (SELECT lo FROM date_bounds)
                                    AND (SELECT hi FROM date_bounds)
    GROUP BY ss_customer_sk
    HAVING COUNT(DISTINCT d_year) = 2
),
c AS (
    SELECT cs_bill_customer_sk AS customer_sk,
           SUM(CASE WHEN d_year = 2001 THEN
               ((cs_ext_list_price-cs_ext_wholesale_cost-cs_ext_discount_amt)+cs_ext_sales_price)/2
           END) AS y1,
           SUM(CASE WHEN d_year = 2002 THEN
               ((cs_ext_list_price-cs_ext_wholesale_cost-cs_ext_discount_amt)+cs_ext_sales_price)/2
           END) AS y2
    FROM catalog_sales
    JOIN date_dim ON cs_sold_date_sk = d_date_sk
    WHERE d_year IN (2001,2002)
      AND cs_sold_date_sk BETWEEN (SELECT lo FROM date_bounds)
                                    AND (SELECT hi FROM date_bounds)
    GROUP BY cs_bill_customer_sk
    HAVING COUNT(DISTINCT d_year) = 2
),
w AS (
    SELECT ws_bill_customer_sk AS customer_sk,
           SUM(CASE WHEN d_year = 2001 THEN
               ((ws_ext_list_price-ws_ext_wholesale_cost-ws_ext_discount_amt)+ws_ext_sales_price)/2
           END) AS y1,
           SUM(CASE WHEN d_year = 2002 THEN
               ((ws_ext_list_price-ws_ext_wholesale_cost-ws_ext_discount_amt)+ws_ext_sales_price)/2
           END) AS y2
    FROM web_sales
    JOIN date_dim ON ws_sold_date_sk = d_date_sk
    WHERE d_year IN (2001,2002)
      AND ws_sold_date_sk BETWEEN (SELECT lo FROM date_bounds)
                                    AND (SELECT hi FROM date_bounds)
    GROUP BY ws_bill_customer_sk
    HAVING COUNT(DISTINCT d_year) = 2
)
SELECT customer.c_customer_id AS customer_id,
       customer.c_first_name AS customer_first_name,
       customer.c_last_name AS customer_last_name,
       customer.c_login AS customer_login
FROM s
JOIN c ON s.customer_sk = c.customer_sk
JOIN w ON s.customer_sk = w.customer_sk
JOIN customer ON customer.c_customer_sk = s.customer_sk
WHERE s.y1 > 0 AND c.y1 > 0 AND w.y1 > 0
  AND CASE WHEN c.y1 > 0 THEN c.y2/c.y1 ELSE NULL END
      > CASE WHEN s.y1 > 0 THEN s.y2/s.y1 ELSE NULL END
  AND CASE WHEN c.y1 > 0 THEN c.y2/c.y1 ELSE NULL END
      > CASE WHEN w.y1 > 0 THEN w.y2/w.y1 ELSE NULL END
ORDER BY customer_id, customer_first_name, customer_last_name, customer_login
LIMIT 100;
